#pragma once
#define _USE_MATH_DEFINES
#include <cmath>
#define MAXFLOAT FLT_MAX
